Clazz.declarePackage ("org.jmol.api");
Clazz.load (["org.jmol.api.QuantumCalculationInterface"], "org.jmol.api.QuantumPlaneCalculationInterface", null, function () {
Clazz.declareInterface (org.jmol.api, "QuantumPlaneCalculationInterface", org.jmol.api.QuantumCalculationInterface);
});
