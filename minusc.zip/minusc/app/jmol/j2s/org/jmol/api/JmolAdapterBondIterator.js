Clazz.declarePackage ("org.jmol.api");
c$ = Clazz.declareType (org.jmol.api, "JmolAdapterBondIterator");
