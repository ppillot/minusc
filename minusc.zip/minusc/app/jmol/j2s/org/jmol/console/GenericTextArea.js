Clazz.declarePackage ("org.jmol.console");
Clazz.declareInterface (org.jmol.console, "GenericTextArea");
