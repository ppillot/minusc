Clazz.declarePackage ("com.jcraft.jzlib");
Clazz.declareInterface (com.jcraft.jzlib, "Checksum");
