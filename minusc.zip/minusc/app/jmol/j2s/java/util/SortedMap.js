$_L(["java.util.Map"],"java.util.SortedMap",null,function(){
$_I(java.util,"SortedMap",java.util.Map);
});
