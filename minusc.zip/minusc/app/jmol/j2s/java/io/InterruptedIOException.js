$_L(["java.io.IOException"],"java.io.InterruptedIOException",null,function(){
c$=$_C(function(){
this.bytesTransferred=0;
$_Z(this,arguments);
},java.io,"InterruptedIOException",java.io.IOException);
});
