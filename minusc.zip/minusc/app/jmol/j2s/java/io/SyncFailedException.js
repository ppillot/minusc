$_L(["java.io.IOException"],"java.io.SyncFailedException",null,function(){
c$=$_T(java.io,"SyncFailedException",java.io.IOException);
});
