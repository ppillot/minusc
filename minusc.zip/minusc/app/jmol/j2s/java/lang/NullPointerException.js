$_L(["java.lang.RuntimeException"],"java.lang.NullPointerException",null,function(){
c$=$_T(java.lang,"NullPointerException",RuntimeException);
});
