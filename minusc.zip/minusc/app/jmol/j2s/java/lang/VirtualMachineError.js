$_L(["java.lang.Error"],"java.lang.VirtualMachineError",null,function(){
c$=$_T(java.lang,"VirtualMachineError",Error);
});
