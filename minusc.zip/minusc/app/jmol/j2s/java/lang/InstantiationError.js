$_L(["java.lang.IncompatibleClassChangeError"],"java.lang.InstantiationError",null,function(){
c$=$_T(java.lang,"InstantiationError",IncompatibleClassChangeError);
});
