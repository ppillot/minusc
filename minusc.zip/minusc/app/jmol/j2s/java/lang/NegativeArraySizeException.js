$_L(["java.lang.RuntimeException"],"java.lang.NegativeArraySizeException",null,function(){
c$=$_T(java.lang,"NegativeArraySizeException",RuntimeException);
});
