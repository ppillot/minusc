Clazz.declarePackage ("javajs.awt");
Clazz.declareInterface (javajs.awt, "EventManager");
