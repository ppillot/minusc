Clazz.declarePackage ("javajs.awt");
c$ = Clazz.declareType (javajs.awt, "LayoutManager");
