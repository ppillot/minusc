Clazz.declarePackage ("javajs.awt.event");
Clazz.load (["javajs.awt.event.Event"], "javajs.awt.event.ItemEvent", null, function () {
c$ = Clazz.declareType (javajs.awt.event, "ItemEvent", javajs.awt.event.Event);
});
