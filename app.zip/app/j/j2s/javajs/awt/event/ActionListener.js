Clazz.declarePackage ("javajs.awt.event");
Clazz.declareInterface (javajs.awt.event, "ActionListener");
