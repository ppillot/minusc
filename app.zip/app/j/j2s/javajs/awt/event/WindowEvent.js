Clazz.declarePackage ("javajs.awt.event");
Clazz.load (["javajs.awt.event.Event"], "javajs.awt.event.WindowEvent", null, function () {
c$ = Clazz.declareType (javajs.awt.event, "WindowEvent", javajs.awt.event.Event);
});
