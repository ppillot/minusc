Clazz.declarePackage ("javajs.api");
Clazz.load (["javajs.api.GenericBinaryDocumentReader"], "javajs.api.GenericBinaryDocument", null, function () {
Clazz.declareInterface (javajs.api, "GenericBinaryDocument", javajs.api.GenericBinaryDocumentReader);
});
