Clazz.declarePackage ("java.net");
Clazz.declareInterface (java.net, "URLStreamHandlerFactory");
