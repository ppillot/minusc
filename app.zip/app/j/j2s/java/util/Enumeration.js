Clazz.declareInterface(java.util,"Enumeration");
