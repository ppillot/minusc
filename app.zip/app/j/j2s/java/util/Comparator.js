Clazz.declareInterface(java.util,"Comparator");
