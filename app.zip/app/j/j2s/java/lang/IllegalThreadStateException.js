Clazz.load(["java.lang.IllegalArgumentException"],"java.lang.IllegalThreadStateException",null,function(){
c$=Clazz.declareType(java.lang,"IllegalThreadStateException",IllegalArgumentException);
});
