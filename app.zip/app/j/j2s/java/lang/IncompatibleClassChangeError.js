Clazz.load(["java.lang.LinkageError"],"java.lang.IncompatibleClassChangeError",null,function(){
c$=Clazz.declareType(java.lang,"IncompatibleClassChangeError",LinkageError);
});
