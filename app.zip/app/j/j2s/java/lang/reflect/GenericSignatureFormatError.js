Clazz.load(["java.lang.ClassFormatError"],"java.lang.reflect.GenericSignatureFormatError",null,function(){
c$=Clazz.declareType(java.lang.reflect,"GenericSignatureFormatError",ClassFormatError);
});
