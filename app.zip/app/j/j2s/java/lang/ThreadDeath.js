Clazz.load(["java.lang.Error"],"java.lang.ThreadDeath",null,function(){
c$=Clazz.declareType(java.lang,"ThreadDeath",Error);
Clazz.makeConstructor(c$,
function(){
Clazz.superConstructor(this,ThreadDeath,[]);
});
});
